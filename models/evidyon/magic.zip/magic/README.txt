//---------------------------------------------------------------------------//
//  The files in this folder and subfolders are part of Evidyon, a 3d        //
//  multiplayer online role-playing game.                                    //
//  Copyright � 2009, 2010 Erich Gluck, Karl Gluck, Stephen Guinn            //
//                                                                           //
//  Evidyon is free software: you can redistribute it and/or modify          //
//  it under the terms of the GNU General Public License as published by     //
//  the Free Software Foundation, either version 3 of the License, or        //
//  (at your option) any later version.                                      //
//                                                                           //
//  Evidyon is distributed in the hope that it will be useful,               //
//  but WITHOUT ANY WARRANTY; without even the implied warranty of           //
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            //
//  GNU General Public License for more details.                             //
//                                                                           //
//  You should have received a copy of the GNU General Public License        //
//  along with Evidyon.  If not, see <http://www.gnu.org/licenses/>.         //
//                                                                           //
//  Karl Gluck can be reached by email at kwg8@cornell.edu                   //
//---------------------------------------------------------------------------//

Stephen Guinn produced the following sounds:
	Beam.wav
	ArrowShot.wav
	heal.wav
	forest-step.wav
	cast.wav
	attwind.wav
	everything in the "/Sounds/" folder


Erich Gluck produced the following files:
	got_hit.wav
	Swing1.wav
	Swing2.wav
	Swing3.wav
	water-step.wav
	Stone.x
	Stone.bmp
	

Karl Gluck produced the remaining files.