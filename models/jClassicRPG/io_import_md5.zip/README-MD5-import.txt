Blender 2.60+/- MD5 Import script
===============================
Script by ShinAli (http://scisbot.com/).
Tracker topic - http://www.katsbits.com/smforum/index.php?topic=358.0

Installation
============
Import script need to be placed in the following location;

	scripts\addons

or it should be loaded through User Preferences

	File > User Preferences... > (Install Add-Ons...)

For Windows Vista/Win7 users Blender's scripts folder is typically located in;

	C:\Users\[profile]\AppData\Roaming\Blender Foundation\Blender\scripts\addons

Windows XP users should look in; 

	C:\Documents and Settings\[profile]\Application Data\Blender Foundation\Blender\scripts\addons

If correctly installed two entries should appear in File > Import
	- "Import id Tech 4 Animation Format (.md5anim)"
	- "Import id Tech 4 MESH Format (.md5mesh)"

Misc
====
For more tools visit
http://www.katsbits.com/tools/

Game editing tutorials available from
http://www.katsbits.com/tutorials/