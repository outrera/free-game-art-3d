Author: Gladiuss 'Raphael Siems'
Model: Salmon
License: CC-BY-SA 3.0
Purpose: Decoration or food item
Notes: some UV-issues, unfinished

Secondary note: del_diablo added simple swim animation