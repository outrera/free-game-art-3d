SPIDER ANIMATIONS

0-45 = Walk
46-65 = Attack 1
66-85 = Attack2
86-99 = Eat
100-120 = Defend
121-134 = Hit 1
135-149 = Hit 2
150-155 = Crouch
157-162 = Stand Tall
164-213 = Idle 1
214-249 = Idle 2
250-269 = Jump
270-279 = Side Step/Turn on the spot
280-299 = Die 1
300-329 = Die 2

Psionic
www.psionicgames.com