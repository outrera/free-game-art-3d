http://freegamearts.tuxfamily.org
Email: wm_jkm@yahoo.com

Description: A muzzleflash model(20tris) and skin(512x512) for a machine gun or similar.

Copyright (C) 2007  Julius Krischan Makowka

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Alternatively you can also use this model under the terms of the
Creative Commons Share Alike 3.0 (or later) license.
