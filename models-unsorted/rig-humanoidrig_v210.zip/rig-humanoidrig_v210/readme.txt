Rig for realtime meshes (Version 2.1)

(c) by Julius Krischan Makowka.

Released under the GPL Version 2 
(or any later version) or the 
Creative Commons "ShareAlike" license.
Contact me if you want to discuss other 
licensing options at jkmakowka@yahoo.de

Visit FreeGameArts:
http://freegamearts.tuxfamily.org
for the latest version.

Number of bones was kept low to allow
for GPU skinning on newer graphic-cards.

Bone-layer 1: Bones for mesh deformation
Bone-layer 2: Bones for animation control
Bone-layer 3: Helper-bones

Known issues: Upper leg IK is a bit of a hack 
to circumvent wrong IK solving that occured 
with a copy rotation constrain (Thanks to 
Orinoco from the Blender forums for that idea).
